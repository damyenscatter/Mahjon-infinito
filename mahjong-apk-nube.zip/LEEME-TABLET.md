# Crear el APK desde la tablet (con GitHub)

GitHub compila el APK por ti en sus servidores. Solo necesitas el navegador.
Si algun boton no aparece, en Chrome pulsa el menu (tres puntos) y marca
"Sitio para ordenador".

## Archivos de este paquete
- index.html            (el juego)
- capacitor.config.json (datos de la app)
- package.json          (datos del proyecto)
- build-apk.yml         (las instrucciones de compilacion)

## Pasos

1. Descomprime este zip en la tablet (app Archivos > pulsa el zip > Extraer).

2. Entra en github.com y crea una cuenta gratuita (confirma el correo).

3. Crea un repositorio: boton "+" > "New repository".
   - Nombre: mahjong-infinito
   - Marca "Add a README file" (asi el repositorio no queda vacio).
   - Pulsa "Create repository".

4. Sube los archivos: "Add file" > "Upload files". Elige los cuatro:
   index.html, capacitor.config.json, package.json y build-apk.yml.
   Pulsa "Commit changes".

5. Mueve build-apk.yml a su sitio:
   - Abre build-apk.yml en el repositorio y pulsa el lapiz (Edit).
   - Pulsa en el nombre del archivo (arriba), ponte al principio y escribe
     delante:  .github/workflows/
     Debe quedar:  .github/workflows/build-apk.yml
   - Pulsa "Commit changes".

6. Esto inicia la compilacion. Abre la pestana "Actions": veras
   "Compilar APK" en marcha. Tarda unos 5 a 10 minutos.
   Si no arranca: Actions > Compilar APK > "Run workflow".

7. Cuando salga el tick verde, abre esa ejecucion y baja hasta "Artifacts".
   Pulsa "mahjong-infinito-apk": se descarga un zip.
   Extraelo y obtendras app-debug.apk.

8. Abre app-debug.apk para instalarlo. Android te pedira permiso para
   instalar apps de origen desconocido: aceptalo.

## Si sale una cruz roja
Abre la ejecucion, entra en el paso que fallo y copia el mensaje de error.

## Actualizar el juego
Sustituye index.html en el repositorio (Add file > Upload files, con el mismo
nombre) y GitHub generara un APK nuevo.

## Notas
- El progreso de la version web no se traslada a la app.
- Los archivos descargados de Actions caducan a los 90 dias; puedes volver a
  lanzarlo con "Run workflow".
